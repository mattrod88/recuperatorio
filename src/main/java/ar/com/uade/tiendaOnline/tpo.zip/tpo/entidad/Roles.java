package ar.com.uade.tiendaOnline.tpo.entidad;


public enum Roles {
    ADMIN,
    CLIENTE
}





