package ar.com.uade.tiendaOnline.tpo.entidad.dto;

import lombok.*;


@Data

public class CategoriaDTO {
    private Long id;
    private String descripcion;
}


