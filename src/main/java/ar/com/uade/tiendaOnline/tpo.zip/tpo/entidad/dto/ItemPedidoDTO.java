package ar.com.uade.tiendaOnline.tpo.entidad.dto;


import lombok.Data;

@Data
public class ItemPedidoDTO {
    private int cantidad;
    private Long id;
}
