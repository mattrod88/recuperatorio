package ar.com.uade.tiendaOnline.tpo.entidad.dto;

import lombok.Data;

@Data
public class ProductoDTO {
    String nombre;
    Long categoria_id;
}
